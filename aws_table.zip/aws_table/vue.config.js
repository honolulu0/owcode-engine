const { defineConfig } = require('@vue/cli-service')
var path = require("path")
module.exports = defineConfig({
  transpileDependencies: true,
  pluginOptions: {
    "style-resources-loader": {
        preProcessor: "less",
        patterns: [
           // 存放less变量文件的路径
            path.resolve(__dirname, "./src/assets/less/parameter.less")
        ]
    }
  }
})
module.exports = {
  devServer:{
      // host:"media-amazon.com",
      host:"w-test.sui10.com",
      port:8080,
      proxy: {
          '/': {
              target: "http://192.168.10.47:3333",
              changeOrigin: true,
              secure: false,
              ws:false,
              pathRewrite: {
                  "^/": ""
              }
          },

      }, // string | Object

     
  },
  publicPath:"/influncers"
}