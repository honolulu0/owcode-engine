<template>
    <div id="DisplayTable">
        <el-container>
          
                <el-aside width="200px">
                      <div class="tree_main">
                    <el-tree :data="treeData" @node-click="handleNodeClick"></el-tree>
                    </div>
                </el-aside>
            
        <el-main>
             <div>
            <!-- <el-input size="mini" style="width:150px" placeholder="输入关键字" v-model="search"></el-input>
            <el-button size="mini"  type="primary">搜索</el-button> -->
            <h3>当前关键字:{{nowKey}}</h3>
            <!-- <el-button size="mini" @click="getDataList"  type="success">刷新列表</el-button> -->
            <el-button size="mini" style="margin-right:5px" @click="exportExcelEventAll" type="success">导出当前批次</el-button>
            <el-button size="mini" style="margin-right:5px" @click="exportExcelEvent" type="success">导出</el-button>
            <span style="font-size:13px">第</span><span style="color:#4da5fc;padding:0 2px;font-weight:bold;font-size:13px">{{numD}}</span>
                <span style="padding-right:15px;font-size:13px">个开始获取 </span>
                <p style="display:inline-block;margin: 0;padding-right:15px;">当前批次一共有<span style="font-weight:bold;color:#4da5fc;">{{dataList.length}}</span>条 <span v-if="dataList.length < 1000">最后一批</span></p>
                跳转到第<el-input placeholder="" size="mini" style="width:80px;margin:0 4px" type="number" v-model="beginValue"></el-input>批
                <el-button size="mini"  type="primary" @click="goJump">跳转</el-button>
            <!-- <el-button size="mini" @click="exportExcelEvent2" type="success">导出(网红筛选)</el-button> -->
            <!-- <el-button size="mini" v-if="!buging" type="warning">开始爬虫</el-button>
            <el-button size="mini" v-else type="danger">暂停爬虫</el-button> -->
        </div>
        <!-- <h3>关键字</h3> -->
        <div class="table_box">
            <el-table
            :data="dataListSp"
            style="width: 100%">
              <el-table-column
                prop="id"
                label="id"
                width="180">
            </el-table-column>
            <el-table-column
                prop="shopTitle"
                label="商品标题"
                width="180">
            </el-table-column>
              <el-table-column
                prop="rankName"
                label="分类"
                width="180">
            </el-table-column>
             <el-table-column
                prop="rank"
                label="名次"
                width="180">
            </el-table-column>
               <el-table-column
                label="商品品牌"
                width="180">
                <template slot-scope="scope">
                    <p >{{scope.row.shopNameText}}</p>
                </template>
            </el-table-column>
             <el-table-column
                prop="shopHref"
                label="品牌链接">
            </el-table-column>
            <el-table-column
                prop="money"
                label="价格">
            </el-table-column>
            <el-table-column
                prop="viewNum"
                label="评论数">
            </el-table-column>
            <el-table-column
                prop="fromsText"
                label="发货方式">
            </el-table-column>
            <el-table-column
                prop="CountryofOrigin"
                label="商品产地">
            </el-table-column>
               <el-table-column
                 prop="dataFirst"
                label="上架日期"
                width="180">
            </el-table-column>
            <el-table-column
                prop="soldName"
                label="店铺名字"
                  width="250">
            </el-table-column>
              <el-table-column
                prop="ASIN"
                label="产品ASIN"
                  width="250">
            </el-table-column>
              <el-table-column
                prop="link"
                label="店铺商品清单链接"
                  width="250">
            </el-table-column>
              <el-table-column
                prop="seller"
                label="seller码"
                  width="250">
            </el-table-column>
             <el-table-column
                prop="soldHref"
                label="店铺链接"
                  width="250">
                   <template slot-scope="scope">
                    <a :href="scope.row.soldHref">{{scope.row.soldHref}}</a>
                </template>
            </el-table-column>
            <el-table-column
                prop="address"
                label="公司地址"
                  width="250">
            </el-table-column>
             <el-table-column
                prop="businessName"
                label="公司名称"
                  width="250">
            </el-table-column>
             <el-table-column
                prop="country"
                label="店铺国家"
                  width="250">

            </el-table-column>
             <el-table-column
                prop="AOKETE"
                label="卖家对话链接"
                  width="250">
                   <template slot-scope="scope">
                     <a :href="scope.row.AOKETE">{{scope.row.AOKETE}}</a>
                </template>
            </el-table-column>
            </el-table>
        </div>
        <div class="pagination_box">
             <!-- <div style="display:inline-block;    vertical-align: middle;">
                <el-pagination
                    @size-change="handleSizeChange"
                    @current-change="handleCurrentChange"
                    :current-page="currentPage"
                    :page-sizes="[10,20,50,100, 200, 300, 400]"
                    :page-size="pageSize"
                    layout="total, sizes, prev, pager, next, jumper"
                    :total="dataList.length">
                </el-pagination>
             </div> -->
             <div style="display:inline-block;    vertical-align: middle;padding-left:10px">
                <el-button size="mini"  type="primary" @click="prePageData">上一批</el-button>
                <el-button size="mini"  type="primary" @click="nextPageData">下一批</el-button>
            </div>
        </div>
        </el-main>
        </el-container>
       
        
    </div>
</template>
<script>
import {postEventToken} from "../../assets/js/common.js"
var XLSX = require("xlsx");
    export default{
        data(){
            return{
                maxKey:0,  //最长字段(关键词)
                dataList:[],
                dataListSp:[],
                userListData:{},
                buging:false, //是否正在爬虫
                search:"",
                pageSize:10,
                currentPage:1,
                numD:0,
                beginValue:1,
                treeDataArr:[],
                treeData: [],
                nowKey:""
            }
        },
        mounted:function(){
            this.getDataList();
        },
        methods:{
            goJump(){
                if(this.beginValue < 1){
                    alert("批数不能小于1")
                }else{
                    this.numD = (this.beginValue-1)*1000
                    this.currentPage = 1
                    // this.queryByClass(this.savecid,"goj")
                    this.getDataList()
                }
                
            },
             prePageData(){
                if(this.numD > 0){
                    this.numD = this.numD - 1000
                    this.beginValue = (this.numD/1000)+1
                    this.currentPage = 1
                    this.getDataList()
                }else{
                    alert("已经是第一批")
                }
            },
            nextPageData(){
                if(this.isLast){
                    alert("已经是最后一批")
                }else{
                     this.numD = this.numD + 1000
                    this.beginValue = (this.numD/1000)+1
                     this.currentPage = 1
                     this.getDataList()
                }
            },
            influncersLink(link){
                if(link.indexOf("##&*%$#") == -1){
                    return link
                }else{
                    return link.split("##&*%$#")[0]
                }
            },
            influncersName(name){
                console.log(name)
                if(name.indexOf("##&*%$#") == -1){
                    return name+","
                }else{
                    return name.split("##&*%$#")[1]+","
                }
            },
             handleSizeChange(val) {
                console.log(`每页 ${val} 条`);
                this.pageSize = val;
                this.dataListSp = this.dataList.slice((this.currentPage-1)*this.pageSize,(this.currentPage-1)*this.pageSize+this.pageSize)
            },
            handleCurrentChange(val) {
                console.log(`当前页: ${val}`);
                this.currentPage = val
                this.dataListSp = this.dataList.slice((this.currentPage-1)*this.pageSize,(this.currentPage-1)*this.pageSize+this.pageSize)
            },
            exportExcelEvent2(){
                console.log(this.maxKey)
                console.log(this.userListData)
                var data = []
                for(let i of Object.entries(this.userListData)){
                     let influncers = i[0]
                        let influncersArr = influncers.split("##&*%$#")
                    let sData = {"网红":"https://www.amazon.com/shop/"+influncersArr}
                    for(let a = 0;a<15;a++){
                        if(i[1][a]){
                            sData["关键词"+(a+1)] = i[1][a]
                        }else{
                            sData["关键词"+(a+1)] = ""
                        }
                        if(a == 14){
                            data.push(sData)
                        }
                    }
                }
                this.exportExcel(data,"关键字表格(网红)")
            },
            exportExcelEventAll(){
                 var data =[]
                for(let a=0 ;a< this.dataList.length;a++){
                    let sData = {
                        "商品标题":this.dataList[a].shopTitle,
                        "分类":this.dataList[a].rankName,
                        "名次":this.dataList[a].rank,
                        "商品品牌":this.dataList[a].shopNameText,
                        "品牌链接":this.dataList[a].shopHref,
                        "价格":this.dataList[a].money,
                        "评论数":this.dataList[a].viewNum,
                        "发货方式":this.dataList[a].fromsText,
                        "商品产地":this.dataList[a].CountryofOrigin,
                        "上架日期":this.dataList[a].dataFirst,
                        "店铺名字":this.dataList[a].soldName,
                        "ASIN":this.dataList[a].ASIN,
                        
                        "商品清单链接":this.dataList[a].link,
                        "seller码":this.dataList[a].seller,
                        "店铺链接":this.dataList[a].soldHref,
                        "公司地址":this.dataList[a].address,
                        "公司名称":this.dataList[a].businessName,
                        "店铺国家":this.dataList[a].country,
                        "卖家对话链接":this.dataList[a].AOKETE,
                    }
                     data.push(sData)
                     if(a == this.dataList.length-1){
                            this.exportExcel(data,"商铺表格")
                        }
                }
            },
            exportExcelEvent(){
                var data =[]
                for(let a=0 ;a< this.dataListSp.length;a++){
                    let sData = {
                        "商品标题":this.dataListSp[a].shopTitle,
                        "分类":this.dataListSp[a].rankName,
                        "名次":this.dataListSp[a].rank,
                        "商品品牌":this.dataListSp[a].shopNameText,
                        "品牌链接":this.dataListSp[a].shopHref,
                        "价格":this.dataListSp[a].money,
                        "评论数":this.dataListSp[a].viewNum,
                        "发货方式":this.dataListSp[a].fromsText,
                        "商品产地":this.dataListSp[a].CountryofOrigin,
                        "上架日期":this.dataListSp[a].dataFirst,
                        "店铺名字":this.dataListSp[a].soldName,
                        "ASIN":this.dataListSp[a].ASIN,
                        
                        "商品清单链接":this.dataListSp[a].link,
                        "seller码":this.dataListSp[a].seller,
                        "店铺链接":this.dataListSp[a].soldHref,
                        "公司地址":this.dataListSp[a].address,
                        "公司名称":this.dataListSp[a].businessName,
                        "店铺国家":this.dataListSp[a].country,
                        "卖家对话链接":this.dataListSp[a].AOKETE,
                    }
                     data.push(sData)
                     if(a == this.dataList.length-1){
                            this.exportExcel(data,this.nowKey+"商铺表格")
                        }
                   
                }
                // var data = [{"aa":1},{"aa":2,"bb":1}]
                // this.exportExcel(data,"关键字表格")
            },
            /**
         * @description: 获取map的长度
         * @param {Object} obj map对象 
         * @return: map的长度
         */
        getLength(obj) {
            var count = 0;
            for (var i in obj) {

                // eslint-disable-next-line no-prototype-builtins
                if (obj.hasOwnProperty(i)) {
                    count++;

                }
            }

            return count;
        },
            exportExcel(json, name) {
                /* convert state to workbook */
                var data = new Array();
                var keyArray = new Array();
            
                for (const key1 in json) {
                    // eslint-disable-next-line no-prototype-builtins
                    if (json.hasOwnProperty(key1)) {
                        const element = json[key1];
                        var rowDataArray = new Array();
                        for (const key2 in element) {
                            // eslint-disable-next-line no-prototype-builtins
                            if (element.hasOwnProperty(key2)) {
                                const element2 = element[key2];
                                rowDataArray.push(element2);
                                if (keyArray.length < this.getLength(element)) {
                                    keyArray.push(key2);
                                }
                            }
                        }
                        data.push(rowDataArray);
                    }
                }
            
                data.splice(0, 0, keyArray);
                console.log(111112,XLSX)
                const ws = XLSX.utils.aoa_to_sheet(data);
                const wb = XLSX.utils.book_new();
                XLSX.utils.book_append_sheet(wb, ws, "SheetJS");
                /* generate file and send to client */
                XLSX.writeFile(wb, name + ".xlsx");
            },
            dateChange(time){
                // return new Date(time)
                var dat = new Date(time*1000)
                var newDate = dat.getFullYear() +"-"+((dat.getMonth()+1)> 9 ? (dat.getMonth()+1) : ("0"+(dat.getMonth()+1)))+"-"+
                (dat.getDate() > 9 ? dat.getDate() : ("0"+dat.getDate()))+" "+(dat.getHours() > 9 ? dat.getHours():"0"+dat.getHours())+
                ":"+(dat.getMinutes() > 9 ? dat.getMinutes():"0"+dat.getMinutes())+":"+(dat.getSeconds()>9? dat.getSeconds():"0"+dat.getSeconds())
                 return newDate
            },
            influncersChange(influncers){
                console.log(influncers)
                return influncers.join(" , ")
            },
            handleNodeClick(e){
                console.log(e)
                this.nowKey = e.label
                let data = e.data
                this.dataListSp = []
                 if(data.length>0){
                    for(let key in data){
                        this.dataListSp.push(data[key])
                        console.log(this.dataListSp)
                    }
                }
            },
            getDataList(){
                this.currentPage = 1
                postEventToken("https://ebus-b1.test.api.sui10.com/json/amz_seller/query",{"req": {"begin": parseInt(this.numD)}},(res)=>{
                    console.log(res)
                    if(res.tars_ret == 0){

                       this.dataList = res.rsp.records
                       for(let i = 0;i<this.dataList.length;i++){
                            let data = this.dataList[i].data ? JSON.parse(this.dataList[i].data) : {}
                            for(let key in data){
                                this.dataList[i][key] = data[key]
                            }
                            // if(i == this.dataList.length - 1){
                            //     this.dataListSp = this.dataList.slice(0,this.pageSize)
                            //     console.log(this.dataList)
                            // }
                            if(this.treeDataArr.indexOf(this.dataList[i].name) ==(-1)){
                                let cData = []
                                 data["id"] = this.dataList[i].id
                                cData.push(data)
                                this.treeData.push({
                                     label: this.dataList[i].name,
                                     data:cData
                                })
                                this.treeDataArr.push(this.dataList[i].name)
                            }else{
                                let indexs = this.treeDataArr.indexOf(this.dataList[i].name)
                                 data["id"] = this.dataList[i].id
                                this.treeData[indexs].push(data)
                            }
//  treeDataArr:[],
//                 treeData: [{
//                         label: '一级 1',
//                         children: [{
//                             label: '二级 1-1',
//                         }]
//                 }],
                       }
                    }
                })
            }
        }
    }
</script>
<style lang="less">
    .tree_main{
        .el-tree{
            .is-current{
                color: aqua;
            }
        }
    }
</style>
<style scoped>
    .tree_main{
        padding-top:1vw ;
        width: 200px;
        height: 98%;
        overflow: auto;
        position: fixed;
        left: 0%;
        top: 0;
        z-index: 20;
    }
    #DisplayTable{
        width: 100%;
        margin: 0 auto;
        padding-bottom: 55px;
    }
    .table_box{
        padding-top: 25px;
        min-height: 500px;
    }
    .pagination_box{
        text-align: center;
        padding-top: 15px;
        height: 50px;
        position: fixed;
        text-align: center;
        left: 0;
        bottom: 0;
        width: 100%;
        background: #fff;
    }
    .user_link{
        text-decoration: none;
        color: #333;
    }
    .user_link:hover{
        color: rgb(79, 138, 222);
    }
</style>