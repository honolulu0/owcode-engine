<template>
    <div id="DisplayTable">
        <div>
            <!-- <el-input size="mini" style="width:150px" placeholder="输入关键字" v-model="search"></el-input>
            <el-button size="mini"  type="primary">搜索</el-button> -->
            <el-button size="mini" @click="getDataList"  type="success">刷新列表</el-button>
            <el-button size="mini" @click="exportExcelEvent" type="success">导出</el-button>
            <el-button size="mini" @click="exportExcelEvent2" type="success">导出(网红筛选)</el-button>
            <!-- <el-button size="mini" v-if="!buging" type="warning">开始爬虫</el-button>
            <el-button size="mini" v-else type="danger">暂停爬虫</el-button> -->
        </div>
        <!-- <h3>关键字</h3> -->
        <div class="table_box">
            <el-table
            :data="dataListSp"
            style="width: 100%">
            <el-table-column
                label="一级分类"
                width="180">
                <template slot-scope="scope">
                    <p  >{{scope.row.class0}}</p>
                </template>
            </el-table-column>
               <el-table-column
                label="二级分类"
                width="180">
                <template slot-scope="scope">
                    <p >{{scope.row.class1}}</p>
                </template>
            </el-table-column>
               <el-table-column
                label="三级分类"
                width="180">
                <template slot-scope="scope">
                    <p> {{scope.row.class2}}</p>
                </template>
            </el-table-column>
            <el-table-column
                prop="name"
                label="网红"
              >
               <template slot-scope="scope">
                    <!-- <p style="font-weight:bold" v-text="influncersChange(scope.row.influncers)"></p> -->
                    <a class="user_link" v-for="(a,ind) in scope.row.influncers" target="_blank" :key="ind" :href="'https://www.amazon.com/shop/'+ influncersLink(a)" v-text="influncersName(a)"></a>
                </template>
            </el-table-column>
            <el-table-column
                prop="timestamp"
                label="爬取时间"
                  width="250">
                   <template slot-scope="scope">
                    <p style="font-weight:bold" v-text="dateChange(scope.row.timestamp)"></p>
                </template>
            </el-table-column>
            </el-table>
        </div>
        <div class="pagination_box">
             <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page="currentPage"
                :page-sizes="[10,20,50,100, 200, 300, 400]"
                :page-size="pageSize"
                layout="total, sizes, prev, pager, next, jumper"
                :total="dataList.length">
            </el-pagination>
        </div>
    </div>
</template>
<script>
import {getEventToken,postEventToken} from "../../assets/js/common.js"
var XLSX = require("xlsx");
    export default{
        data(){
            return{
                maxKey:0,  //最长字段(关键词)
                dataList:[],
                dataListSp:[],
                userListData:{},
                buging:false, //是否正在爬虫
                search:"",
                pageSize:10,
                currentPage:1,
            }
        },
        mounted:function(){
            //  this.getTest()
            this.getDataList();
        },
        methods:{
            influncersLink(link){
                if(link.indexOf("##&*%$#") == -1){
                    return link
                }else{
                    return link.split("##&*%$#")[0]
                }
            },
            influncersName(name){
                console.log(name)
                if(name.indexOf("##&*%$#") == -1){
                    return name+","
                }else{
                    return name.split("##&*%$#")[1]+","
                }
            },
             handleSizeChange(val) {
                console.log(`每页 ${val} 条`);
                this.pageSize = val;
                this.dataListSp = this.dataList.slice((this.currentPage-1)*this.pageSize,(this.currentPage-1)*this.pageSize+this.pageSize)
            },
            handleCurrentChange(val) {
                console.log(`当前页: ${val}`);
                this.currentPage = val
                this.dataListSp = this.dataList.slice((this.currentPage-1)*this.pageSize,(this.currentPage-1)*this.pageSize+this.pageSize)
            },
            exportExcelEvent2(){
                console.log(this.maxKey)
                console.log(this.userListData)
                var data = []
                for(let i of Object.entries(this.userListData)){
                     let influncers = i[0]
                        let influncersArr = influncers.split("##&*%$#")
                    let sData = {"网红":"https://www.amazon.com/shop/"+influncersArr[0]}
                    for(let a = 0;a<15;a++){
                        if(i[1][a]){
                            sData["关键词"+(a+1)] = i[1][a]
                        }else{
                            sData["关键词"+(a+1)] = ""
                        }
                        if(a == 14){
                            data.push(sData)
                        }
                    }
                }
                this.exportExcel(data,"关键字表格(网红)")
            },
            exportExcelEvent(){
                var data =[]
                let finish = false
                for(let a=0 ;a< this.dataList.length;a++){
                    let sData = {"一级分类":this.dataList[a].class0,"二级分类":this.dataList[a].class1,"三级分类":this.dataList[a].class2,"网红":"","爬取时间":this.dateChange(this.dataList[a].timestamp)}
                    let influncersData = []
                    for(let i=0;i<this.dataList[a].influncers.length;i++){
                        let influncers = this.dataList[a].influncers[i]
                        let influncersArr = influncers.split("##&*%$#")
                        influncersData.push("https://www.amazon.com/shop/"+influncersArr[0])
                        if(i == this.dataList[a].influncers.length-1){
                            sData["网红"] = this.influncersChange(influncersData)
                            data.push(sData)
                        }
                        if(i == this.dataList[a].influncers.length-1 ){
                            finish = true
                        }
                        // console.log(i , this.dataList[a].influncers.length-1,a , this.dataList.length-1)
                        
                    }
                    if(a == this.dataList.length-1 && finish == true){
                            this.exportExcel(data,"关键字表格")
                    }
                }
                // var data = [{"aa":1},{"aa":2,"bb":1}]
                // this.exportExcel(data,"关键字表格")
            },
            /**
         * @description: 获取map的长度
         * @param {Object} obj map对象 
         * @return: map的长度
         */
        getLength(obj) {
            var count = 0;
            for (var i in obj) {

                // eslint-disable-next-line no-prototype-builtins
                if (obj.hasOwnProperty(i)) {
                    count++;

                }
            }

            return count;
        },
            exportExcel(json, name) {
                /* convert state to workbook */
                var data = new Array();
                var keyArray = new Array();
            
                for (const key1 in json) {
                    // eslint-disable-next-line no-prototype-builtins
                    if (json.hasOwnProperty(key1)) {
                        const element = json[key1];
                        var rowDataArray = new Array();
                        for (const key2 in element) {
                            // eslint-disable-next-line no-prototype-builtins
                            if (element.hasOwnProperty(key2)) {
                                const element2 = element[key2];
                                rowDataArray.push(element2);
                                if (keyArray.length < this.getLength(element)) {
                                    keyArray.push(key2);
                                }
                            }
                        }
                        data.push(rowDataArray);
                    }
                }
            
                data.splice(0, 0, keyArray);
                console.log(111112,XLSX)
                const ws = XLSX.utils.aoa_to_sheet(data);
                const wb = XLSX.utils.book_new();
                XLSX.utils.book_append_sheet(wb, ws, "SheetJS");
                /* generate file and send to client */
                XLSX.writeFile(wb, name + ".xlsx");
            },
            dateChange(time){
                // return new Date(time)
                var dat = new Date(time*1000)
                var newDate = dat.getFullYear() +"-"+((dat.getMonth()+1)> 9 ? (dat.getMonth()+1) : ("0"+(dat.getMonth()+1)))+"-"+
                (dat.getDate() > 9 ? dat.getDate() : ("0"+dat.getDate()))+" "+(dat.getHours() > 9 ? dat.getHours():"0"+dat.getHours())+
                ":"+(dat.getMinutes() > 9 ? dat.getMinutes():"0"+dat.getMinutes())+":"+(dat.getSeconds()>9? dat.getSeconds():"0"+dat.getSeconds())
                 return newDate
            },
            influncersChange(influncers){
                console.log(influncers)
                return influncers.join(" , ")
            },
            getTest(){
                getEventToken("http://192.168.10.47:3333/getTest",{},(res)=>{
                    console.log(res)
                    
                })
            },
            getDataList(){
                this.currentPage = 1
                postEventToken("https://ebus-b1.test.api.sui10.com/json/amazon/query",{"req": {"token": ""}},(res)=>{
                    console.log(res)
                    if(res.tars_ret == 0){

                       this.dataList = (res.rsp.records).reverse()
                       this.dataListSp = this.dataList.slice(0,this.pageSize)
                       for(let i of this.dataList){
                            if(i.influncers && i.influncers.length>0){
                                for(let a of i.influncers){
                                    if(this.userListData[a]){
                                        this.userListData[a].push(i.class0+"/"+i.class1+"/"+i.class2)
                                        if(this.userListData[a].length > this.maxKey){
                                            this.maxKey =this.userListData[a].length
                                        }
                                    }else{
                                        this.userListData[a]=[(i.class0+"/"+i.class1+"/"+i.class2)]
                                    }
                                }
                            }
                       }
                    }
                })
            }
        }
    }
</script>
<style scoped>
    #DisplayTable{
        width: 90%;
        margin: 0 auto;
        padding-bottom: 55px;
    }
    .table_box{
        padding-top: 25px;
        min-height: 500px;
    }
    .pagination_box{
        text-align: center;
        padding-top: 15px;
        height: 50px;
        position: fixed;
        text-align: center;
        left: 0;
        bottom: 0;
        width: 100%;
        background: #fff;
    }
    .user_link{
        text-decoration: none;
        color: #333;
    }
    .user_link:hover{
        color: rgb(79, 138, 222);
    }
</style>