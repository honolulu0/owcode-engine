<template>
    <el-container>
    <el-aside width="250px" style="border-right:1px solid #efefef;padding-bottom:75px">
        <!-- <el-tree :data="data" :props="defaultProps" ></el-tree> -->
        <div v-if="data">
         <el-tree
      :data="data"
      node-key="id"
      @node-click="handleNodeClick"
      :expand-on-click-node="false">
      <span class="custom-tree-node" slot-scope="{node}" >
        <span >{{ node.label }}</span>
      </span>
    </el-tree>
        </div>
    </el-aside>
    <el-main>
        <div id="DisplayTable">
        
        <div style="position:relative">
            <!-- <el-button size="mini" @click="getDataList"  type="success">刷新列表</el-button> -->
            {{title}}
            <div class="input_mains">
                <span style="color:#333333;padding:0 2px;font-weight:bold;font-size:13px">上一次导出第{{dataTimes}}批</span>
                <span style="font-size:13px">第</span><span style="color:#4da5fc;padding:0 2px;font-weight:bold;font-size:13px">{{numD}}</span>
                <span style="padding-right:15px;font-size:13px">个开始获取 </span>
                <p style="display:inline-block;margin: 0;padding-right:15px;">当前批次一共有<span style="font-weight:bold;color:#4da5fc;">{{userInfoDataArrAll.length}}</span>条 <span v-if="userInfoDataArrAll.length < 1000">最后一批</span></p>
                跳转到第<el-input placeholder="" size="mini" style="width:80px;margin:0 4px" type="number" v-model="beginValue"></el-input>批
                <el-button size="mini"  type="primary" @click="goJump">跳转</el-button>
                <!-- 返回数量：<el-input placeholder="" size="mini" style="width:100px;margin:0 4px" type="number" v-model="dddValue"></el-input> -->
            </div>
            <el-button class="export_btn" size="mini"  type="success" @click="exportExcelReady">导出</el-button>
        </div>
        <!-- <h3>关键字</h3> -->
        <div class="table_box">
            <!-- <el-table
            :data="influncerData"
            style="width: 100%">
            <el-table-column 
               >
                <template slot-scope="scope">
                    <p  >{{scope.row.class1}}</p>
                </template>
            </el-table-column>
              <el-table-column
                label="关键词2"
                >
                <template slot-scope="scope">
                    <p  >{{scope.row.class2}}</p>
                </template>
            </el-table-column>
            <el-table-column
                label="关键词3"
                >
                <template slot-scope="scope">
                    <p  >{{scope.row.class3}}</p>
                </template>
            </el-table-column>
            <el-table-column
                label="网红列表"
                >
                <template slot-scope="scope">
                    <p v-if="scope.row.influncers.length == 0" class="not_datas">无</p>
                    <p v-else class="data_info_btn" @click="getQueryProfile(scope.row.influncers,scope.row)">详情</p>
                </template>
            </el-table-column>
            <el-table-column
                prop="timestamp"
                label="爬取时间"
                  width="250">
                   <template slot-scope="scope">
                    <p style="font-weight:bold" v-text="dateChange(scope.row.timestamp)"></p>
                </template>
            </el-table-column>
            </el-table> -->
             <el-table :data="userInfoDataArr" v-loading="loading">
            <el-table-column property="name" label="社媒名字" >
                 <template slot-scope="scope">
                    <a class="user_link" target="_blank" :href="linkEvent(scope.row)">{{scope.row.name}},</a>
                </template>
            </el-table-column>
            <el-table-column property="subscribes" label="Youtube粉丝数" >
                <template slot-scope="scope">
                    <div class="user_info_text">{{scope.row.subscribes}}</div>
                </template>
            </el-table-column>
            <el-table-column property="location" label="服务站点">
                <template slot-scope="scope">
                    <div class="user_info_text">{{scope.row.location}}</div>
                </template>
            </el-table-column>
            <el-table-column label="前十播放量和时间"  width="200">
                <template slot-scope="scope">
                    <!-- {{scope.row.videos}} -->
                    <div v-if="scope.row.videos">
                        <div class="video_info" v-for="(video,index) in JSON.parse(scope.row.videos)" :key="index">
                            <p v-if="video.url">链接：<a :href="video.url" target="_blank">{{video.url}}</a></p>
                            <p v-if="video.url">播放次数：<span>{{video.plays}}</span></p>
                            <p v-if="video.url">发布时间：<span>{{video.viewCountText}}</span></p>
                        </div>
                    </div>
                </template>
            </el-table-column>
             <el-table-column  label="facebook">
                <template slot-scope="scope">
                    <a class="user_link" target="_blank"  :href="scope.row.facebook">{{scope.row.facebook}},</a>
                </template>
             </el-table-column>
             <el-table-column label="insitagram">
                <template slot-scope="scope">
                   <a class="user_link" target="_blank"  :href="scope.row.insitagram">{{scope.row.insitagram}},</a>
                   </template>
             </el-table-column>
             <el-table-column property="class0" label="类型1" ></el-table-column>
             <el-table-column property="tag0" label="关键字1" ></el-table-column>
               <el-table-column property="class1" label="类型2" ></el-table-column>
             <el-table-column property="tag1" label="关键字2" ></el-table-column>
               <el-table-column property="class2" label="类型3" ></el-table-column>
             <el-table-column property="tag2" label="关键字3" ></el-table-column>
              <el-table-column
                prop="timestamp"
                label="爬取时间"
                  >
                   <template slot-scope="scope">
                    <p style="font-weight:bold" v-text="dateChange(scope.row.timestamp)"></p>
                </template>
            </el-table-column>
        </el-table>
        </div>
        <div class="pagination_box">
             <!-- <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page="currentPage"
                :page-sizes="[10,20,50,100, 200, 300, 400]"
                :page-size="pageSize"
                layout="total, sizes, prev, pager, next, jumper"
                :total="influncerDataAll.length"> 
            </el-pagination> -->
            <div style="display:inline-block;    vertical-align: middle;">
            <el-pagination
                @size-change="handleSizeChangeUser"
                @current-change="handleCurrentChangeUser"
                :current-page="currentPageUser"
                :page-sizes="[10,20,50,100, 200, 300, 400]"
                :page-size="pageSizeUser"
                layout="total, sizes, prev, pager, next, jumper"
                :total="userInfoDataArrAll.length"> 
            </el-pagination>
            </div>
            <div style="display:inline-block;    vertical-align: middle;padding-left:10px">
             <el-button size="mini"  type="primary" @click="prePageData">上一批</el-button>
            <el-button size="mini"  type="primary" @click="nextPageData">下一批</el-button>
            </div>
        </div>
        <el-dialog width="98%" :title="title" :visible.sync="dialogTableVisible">
        <div class="user_btn_main">
            <!-- <el-button size="mini"  type="success" @click="exportExcelEvent">导出</el-button> -->
        </div>
        <el-table :data="userInfoDataArr">
            <el-table-column property="name" label="网红">
                 <template slot-scope="scope">
                    <a class="user_link" target="_blank" :href="linkEvent(scope.row)">{{scope.row.name}},</a>
                </template>
            </el-table-column>
            <el-table-column property="subscribes" label="订阅数" width="300"></el-table-column>
            <el-table-column label="前十播放量和时间">
                <template slot-scope="scope">
                    <!-- {{scope.row.videos}} -->
                    <div v-if="scope.row.videos">
                        <div class="video_info" v-for="(video,index) in JSON.parse(scope.row.videos)" :key="index">
                            <p v-if="video.url">链接：<a :href="video.url" target="_blank">{{video.url}}</a></p>
                            <p v-if="video.url">播放次数：<span>{{video.plays}}</span></p>
                            <p v-if="video.url">发布时间：<span>{{video.viewCountText}}</span></p>
                        </div>
                    </div>
                </template>
            </el-table-column>
             <el-table-column  label="facebook">
                <template slot-scope="scope">
                    <a class="user_link" target="_blank"  :href="scope.row.facebook">{{scope.row.facebook}},</a>
                </template>
             </el-table-column>
             <el-table-column label="insitagram">
                <template slot-scope="scope">
                   <a class="user_link" target="_blank"  :href="scope.row.insitagram">{{scope.row.insitagram}},</a>
                   </template>
             </el-table-column>
              <el-table-column
                prop="timestamp"
                label="爬取时间"
                  width="250">
                   <template slot-scope="scope">
                    <p style="font-weight:bold" v-text="dateChange(scope.row.timestamp)"></p>
                </template>
            </el-table-column>
        </el-table>
        <div class="user_pagination_box">
             <el-pagination
                @size-change="handleSizeChangeUser"
                @current-change="handleCurrentChangeUser"
                :current-page="currentPageUser"
                :page-sizes="[10,20,50,100, 200, 300, 400]"
                :page-size="pageSizeUser"
                layout="total, sizes, prev, pager, next, jumper"
                :total="userInfoDataArrAll.length"> 
            </el-pagination>
           
        </div>
        </el-dialog>
    </div>
    </el-main>
    </el-container>
    
</template>
<script>
import {postEventToken,cookie} from "../../assets/js/common.js"
var XLSX = require("xlsx");
    export default{
        data(){
            return{
                maxKey:0,  //最长字段(关键词)

                buging:false, //是否正在爬虫
                search:"",

                pageSize:10,
                currentPage:1,
                influncerData:[],
                influncerDataAll:[],
                title:"关键词:",
                userInfoDataArr:[],
                userInfoDataArrAll:[],
                dialogTableVisible:false,
                savecid:0,
                currentPageUser:1,
                pageSizeUser:10,
                beginValue:1,
                dddValue:0,
                 data: [],
                defaultProps: {
                    children: 'children',
                    label: 'label'
                },
                classList:[],
                numD:0,
                isLast:false,
                loading:false,
                dataTimes:0,
                saveKey:""

            }
        },
        mounted:function(){
            this.getQueryClass();
            // this.queryStruct();
        
            setTimeout(()=>{
                // this.getDataList();
            },1000)
        },
        methods:{
            handleNodeClick(data) {
                this.numD = 0
                this.currentPageUser = 1
                this.beginValue = 1
                this.saveKey = data.label
                console.log(22,data);
                // let class0 = ""
                // let class1 = ""
                // let class2 = ""
                // if(data.type == 1){
                //      class0 = data.label
                    
                // }else if(data.type == 2){
                //     class0 = data.label1
                //     class1 = data.label
                    
                // }else if(data.type == 3){
                //    class0 = data.label1
                //     class1 = data.label2
                //     class2 = data.label
                // }
                // this.queryByTag(class0,class1,class2)
                this.queryByClass(data.id)
            },
            prePageData(){
                if(this.numD > 0){
                    this.numD = this.numD - 1000
                    this.beginValue = (this.numD/1000)+1
                    this.currentPageUser = 1
                    this.queryByClass(this.savecid)
                }else{
                    alert("已经是第一批")
                }
            },
            nextPageData(){
                if(this.isLast){
                    alert("已经是最后一批")
                }else{
                     this.numD = this.numD + 1000
                    this.beginValue = (this.numD/1000)+1
                     this.currentPageUser = 1
                     this.queryByClass(this.savecid)
                }
            },
            goJump(){
                if(this.beginValue < 1){
                    alert("批数不能小于1")
                }else{
                    this.numD = (this.beginValue-1)*1000
                this.currentPageUser = 1
                this.queryByClass(this.savecid,"goj")
                }
                
            },
            queryByClass(cid,type){
                 this.savecid = cid
                 this.loading = true
                 let saveData = this.userInfoDataArrAll
                 this.userInfoDataArrAll = []
                 this.userInfoDataArr = []
                 this.title = "关键词："+this.saveKey
                 postEventToken("https://ebus-b1.test.api.sui10.com/json/external/queryByClass",{"req": {
                    "token": "",
                    "cid":cid,
                    "begin":parseInt(this.numD)
                    }},(res)=>{
                        // console.log(res)
                       if(res.tars_ret == 0){
                        // console.log(res.rsp.profiles)
                        if(res.rsp.profiles.length <1000){
                            this.isLast = true
                        }else{
                            this.isLast = false
                        }
                        if(res.rsp.profiles.length > 0){
                              this.dataTimes =  cookie.get("dataTimes"+this.saveKey) ? cookie.get("dataTimes"+this.saveKey): 0
                            this.userInfoDataArrAll = res.rsp.profiles
                            this.userInfoDataArr = this.userInfoDataArrAll.slice(0,this.pageSizeUser)
                           setTimeout(()=>{
                            this.loading = false
                           },1000)
                        }else{
                            this.loading = false
                            if(type == "goj"){
                                alert("超过数据批数,请重新输入")
                                this.userInfoDataArrAll = saveData
                                this.userInfoDataArr = this.userInfoDataArrAll.slice(0,this.pageSizeUser)
                            }else{
                                this.userInfoDataArrAll = []
                                this.userInfoDataArr = []
                                this.currentPageUser = 1
                            }
                            
                        }
                    }
                        
                })
            },
            queryByTag(class0,class1,class2){
                postEventToken("https://ebus-b1.test.api.sui10.com/json/external/queryByTag",{"req": {
                    "token": "",
                    "tag":{
                        class0,
                        class1,
                        class2
                    }
                    }},(res)=>{
                        // console.log(res)
                        if(res.tars_ret == 0){
                            if(res.rsp.records.length>0){
                                let data = res.rsp.records[0]
                                this.getQueryProfile(data.influncers,data)
                                
                            }
                        }
                        
                })
            },
            queryStruct(){
                postEventToken("https://ebus-b1.test.api.sui10.com/json/external/queryStruct",{"req": {"token": ""}},(res)=>{
                    // console.log("queryStruct",res)
                    if(res.tars_ret == 0){
                        let tagData = res.rsp.tags
                        let tagObj = {}
                        for(let i = 0; i<tagData.length;i++){
                            if(!tagObj[tagData[i].class0]){
                                tagObj[tagData[i].class0] = {
                                    id:tagData[i].class0+i,
                                    label: tagData[i].class0,
                                    children: [],
                                    type:1
                                }
                            }
                            
                            if(tagData[i].class1 && !tagObj[tagData[i].class0][tagData[i].class1]){
                                tagObj[tagData[i].class0].children.push({
                                        id:tagData[i].class1+i,
                                        label:tagData[i].class1,
                                        label1:tagData[i].class0,
                                        children:[],
                                        type:2
                                    })
                                tagObj[tagData[i].class0][tagData[i].class1] =tagObj[tagData[i].class0].children.length-1
                            }

                            if(tagData[i].class2 && tagObj[tagData[i].class0].children[tagObj[tagData[i].class0][tagData[i].class1]] &&
                             !tagObj[tagData[i].class0].children[tagObj[tagData[i].class0][tagData[i].class1]][tagData[i].class2]){
                                console.log(222)
                                tagObj[tagData[i].class0].children[tagObj[tagData[i].class0][tagData[i].class1]][tagData[i].class2] = i
                                tagObj[tagData[i].class0].children[tagObj[tagData[i].class0][tagData[i].class1]].children.push({
                                    label:tagData[i].class2,
                                    label1:tagData[i].class0,
                                    label2:tagData[i].class1,
                                     id:tagData[i].class2+i,
                                     type:3
                                })
                            }

                            if(i == tagData.length-1){
                                let tagDataArr = Object.entries(tagObj)
                                let cTagDatas = [];
                                for(let a = 0;a<tagDataArr.length;a++){
                                    cTagDatas.push(tagDataArr[a][1])
                                    if(a == tagDataArr.length - 1){
                                        this.data = cTagDatas
                                        console.log("asd",this.data)
                                    }
                                }
                            }
                        }
                    }
                })
            },
            linkEvent(data){
                return data.homepage
                // if(data.videos){
                //     let videoArr = JSON.parse(data.videos)
                //     console.log(videoArr)
                //     if(videoArr.length > 0 &&  videoArr[0].canonicalBaseUrl){
                //         return "https://www.youtube.com"+ videoArr[0].canonicalBaseUrl 
                //     }else{
                //         return false
                //     }
                // }else{
                //     return false
                // }
            },
            handleSizeChange(val) {
                console.log(`每页 ${val} 条`);
                this.pageSize = val;
                this.influncerData = this.influncerDataAll.slice((this.currentPage-1)*this.pageSize,(this.currentPage-1)*this.pageSize+this.pageSize)
            },
            handleCurrentChange(val) {
                console.log(`当前页: ${val}`);
                this.currentPage = val
                console.log(this.currentPage-1*this.pageSize,this.currentPage-1*this.pageSize+this.pageSize)
                this.influncerData = this.influncerDataAll.slice((this.currentPage-1)*this.pageSize,(this.currentPage-1)*this.pageSize+this.pageSize)
                console.log(this.influncerData)
            },
            handleSizeChangeUser(val) {
                console.log(`每页 ${val} 条`);
                this.pageSize = val;
                this.userInfoDataArr = this.userInfoDataArrAll.slice((this.currentPageUser-1)*this.pageSizeUser,(this.currentPageUser-1)*this.pageSizeUser+this.pageSizeUser)
            },
            handleCurrentChangeUser(val) {
                console.log(`当前页: ${val}`);
                this.currentPageUser = val
                this.userInfoDataArr = this.userInfoDataArrAll.slice((this.currentPageUser-1)*this.pageSizeUser,(this.currentPageUser-1)*this.pageSizeUser+this.pageSizeUser)
                console.log(this.userInfoDataArr)
            },
             exportExcelReady(){
                //  this.queryByClass(this.savecid)
                // setTimeout(()=>{
                    this.exportExcelEvent()
                // },1500)
             },
             exportExcelEvent(){
                var data =[]
                for(let a=0 ;a< this.userInfoDataArrAll.length;a++){
                    let sData = {
                        "社媒名字":this.userInfoDataArrAll[a].name,
                        "Youtube粉丝数":this.userInfoDataArrAll[a].subscribes,
                        "服务站点":this.userInfoDataArrAll[a].location,
                        "Youtube":this.userInfoDataArrAll[a].homepage,//\n
                        "播放量1":"",
                        "发布时间1":"",
                        "播放量2":"",
                        "发布时间2":"",
                        "播放量3":"",
                        "发布时间3":"",
                        "播放量4":"",
                        "发布时间4":"",
                        "播放量5":"",
                        "发布时间5":"",
                        "播放量6":"",
                        "发布时间6":"",
                        "播放量7":"",
                        "发布时间7":"",
                        "播放量8":"",
                        "发布时间8":"",
                        "播放量9":"",
                        "发布时间9":"",
                        "播放量10":"",
                        "发布时间10":"",
                        "facebook":this.userInfoDataArrAll[a].facebook,
                        "insitagram":this.userInfoDataArrAll[a].insitagram,
                        "爬取时间":this.dateChange(this.userInfoDataArrAll[a].timestamp),
                    }
                    let vidoes = this.userInfoDataArrAll[a].videos ? JSON.parse(this.userInfoDataArrAll[a].videos) : [];
                    if(vidoes.length > 0){
                        // canonicalBaseUrl + "/videos"
                        // sData["网红主页"] = "https://www.youtube.com"+ (vidoes[0].canonicalBaseUrl ? vidoes[0].canonicalBaseUrl : "")
                          for(let i = 0 ;i<vidoes.length;i++){
                            // sData["视频"+(i+1)] = vidoes[i].url
                            if(vidoes[i].plays){
                                sData["播放量"+(i+1)] = vidoes[i].plays
                                sData["发布时间"+(i+1)] = vidoes[i].viewCountText
                            }
                            // sData["前十播放量和时间"] =sData["前十播放量和时间"]+ "链接："+vidoes[i].url+"\n"+"播放次数："+ vidoes[i].plays+
                            // "\n"+"发布时间："+vidoes[i].viewCountText+"\n\n"
                            if(i == vidoes.length-1){
                                data.push(sData)
                                if(a == this.userInfoDataArrAll.length-1){
                                    this.exportExcel(data,this.title+"表格")
                                }
                            }
                        }
                    }else{
                         data.push(sData)
                        if(a == this.userInfoDataArrAll.length-1){
                            this.exportExcel(data,this.title+"表格")
                        }
                    }
                  

                        
                }
                // var data = [{"aa":1},{"aa":2,"bb":1}]
                // this.exportExcel(data,"关键字表格")
            },
             exportExcel(json, name) {
                /* convert state to workbook */
                var data = new Array();
                var keyArray = new Array();
            
                for (const key1 in json) {
                    // eslint-disable-next-line no-prototype-builtins
                    if (json.hasOwnProperty(key1)) {
                        const element = json[key1];
                        var rowDataArray = new Array();
                        for (const key2 in element) {
                            // eslint-disable-next-line no-prototype-builtins
                            if (element.hasOwnProperty(key2)) {
                                const element2 = element[key2];
                                rowDataArray.push(element2);
                                if (keyArray.length < this.getLength(element)) {
                                    keyArray.push(key2);
                                }
                            }
                        }
                        data.push(rowDataArray);
                    }
                }
            
                data.splice(0, 0, keyArray);
                const ws = XLSX.utils.aoa_to_sheet(data);
                const wb = XLSX.utils.book_new();
                XLSX.utils.book_append_sheet(wb, ws, "SheetJS");
                /* generate file and send to client */
                XLSX.writeFile(wb, name + ".xlsx");
                cookie.set("dataTimes"+this.saveKey,this.beginValue)
                this.dataTimes = this.beginValue
            },
        /**
         * @description: 获取map的长度
         * @param {Object} obj map对象 
         * @return: map的长度
         */
        getLength(obj) {
            var count = 0;
            for (var i in obj) {
                // eslint-disable-next-line no-prototype-builtins
                if (obj.hasOwnProperty(i)) {
                    count++;
                }
            }

            return count;
        },
            dateChange(time){
                // return new Date(time)
                var dat = new Date(time*1000)
                var newDate = dat.getFullYear() +"-"+((dat.getMonth()+1)> 9 ? (dat.getMonth()+1) : ("0"+(dat.getMonth()+1)))+"-"+
                (dat.getDate() > 9 ? dat.getDate() : ("0"+dat.getDate()))+" "+(dat.getHours() > 9 ? dat.getHours():"0"+dat.getHours())+
                ":"+(dat.getMinutes() > 9 ? dat.getMinutes():"0"+dat.getMinutes())+":"+(dat.getSeconds()>9? dat.getSeconds():"0"+dat.getSeconds())
                 return newDate
            },
           getDataList(){
                this.currentPage = 1;
                postEventToken("https://ebus-b1.test.api.sui10.com/json/external/query",{"req": {"token": ""}},(res)=>{
                    console.log(res)
                    if(res.tars_ret == 0){
                        // this.influncerDataAll = (res.rsp.records).reverse()
                        this.influncerDataAll = res.rsp.records
                          this.influncerData = this.influncerDataAll.slice(0,this.pageSize)
                        console.log( this.influncerData.length)
                    }
                })
            },
            getQueryProfile(names){
                // this.dialogTableVisible = true;
                this.currentPageUser1;
                this.userInfoDataArr=[];
                this.userInfoDataArrAll=[];
                postEventToken("https://ebus-b1.test.api.sui10.com/json/external/query_profile",{"req": {"token": "",names}},(res)=>{
                    if(res.tars_ret == 0){
                        // console.log(res.rsp.profiles)
                        if(res.rsp.profiles.length > 0){
                           
                            this.userInfoDataArrAll = res.rsp.profiles
                             this.userInfoDataArr = this.userInfoDataArrAll.slice(0,this.pageSizeUser)
                        }
                    }
                })
            },
            getQueryClass(){
                  postEventToken("https://ebus-b1.test.api.sui10.com/json/external/queryClass",{"req": {"token": ""}},(res)=>{
                    if(res.tars_ret == 0){
                        console.log(res)
                        this.classList = res.rsp.classes
                        let parentList = {}
                        let subParsetList = {}
                        console.log("sfsdfsdf",this.saveKey)
                        for(let i = 0; i<this.classList.length;i++){
                            if(!this.classList[i].parent){
                                parentList[this.classList[i].id] = {
                                    id:this.classList[i].id,
                                    label:this.classList[i].name,
                                    children:[]
                                }
                            }else{
                                subParsetList[this.classList[i].id] = {
                                    id:this.classList[i].id,
                                    label:this.classList[i].name,
                                    children:[],
                                    parent:this.classList[i].parent
                                }
                            }
                            if(i == this.classList.length-1){
                                // let subList = {}
                                let subParsetArr = Object.entries(subParsetList)
                                for(let a of subParsetArr){
                                    subParsetList
                                    if(subParsetList[a[1].parent]){
                                        subParsetList[a[1].parent].children.push({
                                            id:a[1].id,
                                            label:a[1].label,
                                            parent:a[1].parent
                                        })
                                    }
                                    if(a[0] == subParsetArr[subParsetArr.length-1][0]){
                                        // console.log(subParsetList)
                                        let newsubParsetList = Object.entries(subParsetList)
                                        for(let item of newsubParsetList){
                                            // console.log(parentList,item[1].parent)
                                            if(parentList[item[1].parent]){
                                                parentList[item[1].parent].children.push({
                                                    id:item[1].id,
                                                    label:item[1].label,
                                                    parent:item[1].parent,
                                                    children:item[1].children
                                                })
                                            }

                                             if(item[0] == newsubParsetList[newsubParsetList.length-1][0]){
                                                let parentArr = Object.entries(parentList)
                                                let newData = []
                                                for(let el of parentArr){
                                                   newData.push(el[1]) 
                                                    if(el[0] == parentArr[parentArr.length-1][0]){
                                                        this.data = newData
                                                        console.log(this.data)
                                                    }
                                                }
                                             }
                                        }
                                    }
                                }
                            }                        
                        }
                    }
                })
            },
            classLisTypeChange(){

            }
        }
    }
</script>
<style scoped lang="less">
    #DisplayTable{
        width: 95%;
        margin: 0 auto;
        padding-bottom: 55px;
        .input_mains{
            position: absolute;
            top: 0;
            right: 80px;
            font-size: 13px;
        }
        .export_btn{
            position: absolute;
            top: 0;
            right: 0;
        }
    }
    .table_box{
        padding-top: 25px;
        min-height: 500px;
    }
    .pagination_box{
        text-align: center;
        padding-top: 15px;
        height: 50px;
        position: fixed;
        text-align: center;
        left: 0;
        bottom: 0;
        width: 100%;
        background: #fff;
    }
    .user_link{
        display: inline-block;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        text-decoration: none;
        color: #333;
        width: 100%;
    }
    .user_info_text{
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        width: 100%;
    }
    .user_link:hover{
        color: rgb(79, 138, 222);
    }
    .data_info_btn{
        color: rgb(79, 138, 222);
        cursor: pointer;
        &:hover{
            text-decoration: underline;
        }
    }
    .video_info{
        padding-bottom: 10px;
        p{
            padding: 0;
            margin: 0;
            a{
                 color: rgb(79, 138, 222);
            }
            span{
                color: #000;
            }
        }
    }
    .user_pagination_box{
        padding-top: 10px;
        text-align: center;
    }
</style>
<style lang="less">
    .el-tree-node.is-expanded{
        border-left: 3px solid #999;
    }
</style>