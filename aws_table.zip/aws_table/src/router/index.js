// import Vue from 'vue'
import Vue from 'vue'
import VueRouter from 'vue-router'
Vue.use(VueRouter)

// import userMenu from "../page/userMenu/userMenu.vue"
// import importList from "../page/importList/importList.vue"
import ImportBox from "../page/ImportBox/ImportBox.vue"
import DisplayTable from "../page/DisplayTable/DisplayTable.vue"
import DisplayTableYouTub from "../page/DisplayTableYouTub/DisplayTableYouTub.vue"
import AmzShopDisplay from "../page/AmzShopDisplay/AmzShopDisplay.vue"
import AmzShopDisplay2 from "../page/AmzShopDisplay/AmzShopDisplay2.vue"

const originalPush = VueRouter.prototype.push;
VueRouter.prototype.push = function push(location){
    return originalPush.call(this,location).catch(err=>err)
}

const routes = [
    {
        path:'/',
        redirect:'/DisplayTable'
    },
    {
        path:'/ImportBox',
        name: "ImportBox",
        component: ImportBox
    },
    {
        path:'/DisplayTable',
        name: "DisplayTable",
        component: DisplayTable
    },
    {
        path:"/DisplayTableYouTub",
        name:"DisplayTableYouTub",
        component:DisplayTableYouTub
    },
    {
        path:"/AmzShopDisplay",
        name:"AmzShopDisplay",
        component:AmzShopDisplay
    },
    {
        path:"/AmzShopDisplay2",
        name:"AmzShopDisplay2",
        component:AmzShopDisplay2
    }
]



const router = new VueRouter({
  // mode: 'history',
  routes
})

export default router

