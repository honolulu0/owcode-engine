import axios from 'axios'
export const  getEventToken=function(url,data,sCallback,eCallback){
    console.log(data)
    axios({
        method:'get',
        url:url,
        headers: { 'content-type': 'application/x-www-form-urlencoded' },
        withCredentials: false,
        data: data
    }).then((res)=>{
        sCallback && sCallback(res);
    }).catch((err)=>{
        console.log(err);
        eCallback && eCallback(err);
    })
}
export const  postEventToken=function(url,data,sCallback,eCallback){
    console.log(data)
    axios({
        method:'post',
            url:url,
            headers: {  'content-type': 'application/json'},
            withCredentials: false,
            data: data
    }).then((res)=>{
        if(res.status == 200){
            sCallback && sCallback(res.data);
        }
        
    }).catch((err)=>{
        console.log(err);
        eCallback && eCallback(err);
    })
}

export const cookie = {
    get: function (name) { // 获取
        var arr = document.cookie.match(new RegExp('(^| )' + name + '=([^;]*)(;|$)'));
        if (arr != null) {
            return decodeURI(arr[2]);
        }
        return null;
    },
    set: function (name, value, days) { // 设置
        var Days = days || 30; // 保存天数
        var exp = new Date(); // new Date("December 31, 9998");
        exp.setTime(exp.getTime() + Days * 24 * 60 * 60 * 1000);
        var expire = 'expires=' + exp.toGMTString();
        //;domain=.nimo.tv
        var cookieValue = name + '=' + encodeURI(value) + ';domain=.sui10.com;path=/;' + expire;
        document.cookie = cookieValue;
        cookieValue = name + '=' + encodeURI(value) + ';domain=spider-1315031832.cos.ap-guangzhou.myqcloud.com;path=/;' + expire;
        document.cookie = cookieValue;
    },
    del: function (name) { // 删除
        var exp = new Date();
        exp.setTime(exp.getTime() - 1);
        var cval = this.get(name);
        if (cval != null) {
            document.cookie = name + '=' + cval + ';domain=.sui10.com;path=/;expires=' + exp.toGMTString();
            document.cookie = name + '=' + cval + ';domain=spider-1315031832.cos.ap-guangzhou.myqcloud.com;path=/;expires=' + exp.toGMTString();
            document.cookie = name + '=' + cval + ';domain=spider-1315031832.cos.ap-guangzhou.myqcloud.com;path=/;expires=' + exp.toGMTString();
          
        }
    }
}