<template>
    <div class="common-layout">
    <el-container>
      <el-aside width="200px">
        <navMain></navMain>
      </el-aside>
      <el-main>
        <div class="updata_main">
            <p class="updata_title">ASIN码上传页</p>
            <div class="updata_menu">
                <div class="updata_menu_title">
                    上传信息填写
                </div>
                <p class="updata_info_title">上传人信息</p>
                <el-form
                    :model="ruleForm"
                    :rules="rules"
                    class="updata_from"

                     ref="ruleFormRef"
                    label-width="100px"
                    status-icon
                >
                <el-row style="margin-bottom:10px">
                    <el-col :span="6" style="margin-right:10px">
                        <el-form-item label="姓名" prop="name">
                        <el-input v-model="ruleForm.name" />
                        </el-form-item>
                        
                    </el-col>
                    <el-col :span="6">
                        <el-form-item label="手机号" prop="phone">
                        <el-input v-model="ruleForm.phone" />
                        </el-form-item>
                        
                    </el-col>
                </el-row>
                <el-row style="margin-bottom:10px">
                    <el-form-item label="上传时间" prop="uploadData">
                         <el-date-picker
                         style="width:207px;font-size:12px"
                            v-model="ruleForm.uploadDate"
                            type="date"
                            placeholder="选择日期"
                        />
                    </el-form-item>
                </el-row>
                  <el-row style="margin-bottom:10px" :gutter="20">
                     <el-col :span="12">
                     <el-form-item label="上传内容简介" prop="desc">
                        <el-input v-model="ruleForm.desc" type="textarea" />
                    </el-form-item>
                     </el-col>
                 </el-row>
                   <el-row style="margin-bottom:10px">
                    <el-col :span="2" style="font-size:12px;font-weight: bold;">上传文件</el-col>
                    <el-col :span="12">
                        <el-upload
                            v-model:file-list="fileList"
                            class="upload-demo"
                            auto-upload="false"
                            multiple
                            :http-request="uploadEvent"
                            :on-preview="handlePreview"
                            :on-remove="handleRemove"
                            :before-remove="beforeRemove"
                            :limit="1"
                            accept="application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                            :on-exceed="handleExceed"
                        >
                            <el-button type="primary">点击上传</el-button>
                            <template #tip>
                            <div class="el-upload__tip">
                                文件为xls或xlsx.
                            </div>
                            </template>
                        </el-upload>
                    </el-col>
                   </el-row>
                   <el-row style="padding:50px 0 30px 100px">
                        <el-button @click="updataAsin" type="primary">确定</el-button>
                        <el-button @click="resetEvent">取消</el-button>
                   </el-row>
             </el-form>
            </div>
        </div>
      </el-main>
    </el-container>
  </div>
</template>
<script>
import { defineComponent } from '@vue/composition-api'
import navMain from "../components/navMain.vue"
import { ElMessage, ElMessageBox } from 'element-plus'
import { ref  } from 'vue'
import {useRouter} from 'vue-router'
import {postEventTokenAuthorization,cookie} from '../js/common'
export default defineComponent({
    setup() {
        const router = useRouter()
        if(!cookie.get("token")){
          ElMessage({
              message: "登录过期，请先登录",
              type: 'warning',
          })
          router.push("/Login")  
        }
        let ruleForm = ref({
                name: '',
                phone:"",
                desc:"",
                uploadDate:""
                
            })
        const resetEvent=()=>{
            ruleForm.value={
                name: '',
                phone:"",
                desc:"",
                uploadDate:""
            }
            // isUpType.value
            fileList.value = new FormData()
        }
        const rules=ref({
             name: [
                { required: true, message: '请输入姓名', trigger: 'blur' },
            ],
            phone:[
                 { required: true,pattern:/^1[3456789]\d{9}$/, message: '请输入电话号码', trigger: 'blur' },
            ],
            uploadDate:[
                { required: true, message: '请输入日期', trigger: 'blur' },
            ]
        })
          const fileList = ref([
        // {
        //     name: 'element-plus-logo.svg',
        //     url: 'https://element-plus.org/images/element-plus-logo.svg',
        // },
        ])
        const getBase64=(file)=> {
            return new Promise((resolve, reject) => {
                let reader = new FileReader()
                let fileResult = ''
                reader.readAsDataURL(file) //开始转
                reader.onload = function () {
                    fileResult = reader.result
                } //转 失败
                reader.onerror = function (error) {
                    reject(error)
                } //转 结束  咱就 resolve 出去
                reader.onloadend = function () {
                    resolve(fileResult)
                }
            })
        }
        const uploadEvent = (params)=>{
            console.log(params)
             let formData = new FormData()
             getBase64(params.file).then((base)=>{
                 formData.append('fileData',base)
                formData.append('fileName',params.file.name)
                formData.append('module',"ASIN")
                let a = cookie.get("token")
                console.log(a)
                
                postEventTokenAuthorization("http://175.178.91.130/api/Common/UploadFileByBase64",formData,a,(res)=>{
                    console.log(res)
                    console.log(fileList.value)
                    if(res.data && res.data.FileName){
                        fileList.value[fileList.value.length-1].name = res.data.FileName
                    }else{
                        ElMessage({
                            message: res.errorMsg,
                            type: 'warning',
                        })
                    }
                    
                },(err)=>{
                    console.log(err)
                    ElMessage({
                            message: err,
                            type: 'warning',
                        })
                })
             })
        }
        const updataAsin = ()=>{
            let url = "http://175.178.91.130/api/AMZ/AddASIN"
            if(!ruleForm.value.name){
                   ElMessage({
                        message: "请输入姓名",
                        type: 'warning',
                    })
                return false
            }else if(!ruleForm.value.phone){
                ElMessage({
                        message: "请输入电话",
                        type: 'warning',
                    })
                return false
            }else if(!ruleForm.value.uploadDate){
                ElMessage({
                        message: "请输入日期",
                        type: 'warning',
                    })
                return false
            }else if(fileList.value == {}){
                ElMessage({
                        message: "请上传文件",
                        type: 'warning',
                    })
                return false
            }
            let asinFile = []
            for(let i = 0; i < fileList.value.length;i++){
                asinFile.push(fileList.value[i].name)
            }
           let a = cookie.get("token")
            postEventTokenAuthorization(url,{
                 "name": ruleForm.value.name,
                "phone": ruleForm.value.phone,
                "uploadTime": ruleForm.value.uploadDate,
                "content": ruleForm.value.desc,
                "asinFiles":asinFile
            },a,(res)=>{
                console.log(res)
                if(res.errorCode == 401){
                    ElMessage({
                        message: res.errorMsg,
                        type: 'warning',
                    })
                    router.push("/Login")
                }else{
                     ElMessage({
                        message: res.data,
                        type: 'success',
                    })
                    ruleForm.value={
                        desc:"",
                        uploadDate:""
                    }
                }

                resetEvent()
    
                
            },(err)=>{
                console.log(err)
            })
        }
      

const handleRemove = (file, uploadFiles) => {
  console.log(file, uploadFiles)
}

const handlePreview = (uploadFile) => {
  console.log(uploadFile)
}

const handleExceed = (files, uploadFiles) => {
  ElMessage.warning(
    `只能上传一个文件 ${files.length} 已经选择 ${
      files.length + uploadFiles.length
    } `
  )
}

const beforeRemove = (uploadFile) => {
  return ElMessageBox.confirm(
    `Cancel the transfert of ${uploadFile.name} ?`
  ).then(
    () => true,
    () => false
  )
}

        return{
            ruleForm,
            rules,
            fileList,
            handleRemove,
            handlePreview,
            handleExceed,
            beforeRemove,
            resetEvent,
            uploadEvent,
            updataAsin
        }
    },
    components:{
        navMain
    }
})
</script>
<style lang="scss">
    .common-layout{
        .el-main{
            padding: 0 0 0 0;
            background: #f0f2f5;
            .el-form-item__label{
                font-size: 12px;
                font-weight: bold;
            }
            .el-button span{
                font-size: 12px;
            }
        }
        .updata_main{
            background: #f0f2f5;
            width: 100%;
        }
        .updata_title{
            background: #fff;
            font-size: 16px;
            padding: 10px 10px 10px 20px;
            margin: 0;
            font-weight: bold;
            margin-bottom: 10px;
        }
        .updata_menu{
            padding: 10px;
            background: #fff;
            .updata_menu_title{
                background: #e9e9e9;
                padding: 8px 10px;
                font-size: 14px;
                font-weight: bold;
            }
            .updata_info_title{
                padding: 10px 40px;
                font-size: 14px;
                 font-weight: bold;
            }
        }
        .updata_from{
            padding: 0 0 0 70px
        }
        
    }
    
</style>
