<template>
    <div id="loginMain">
        <div class="login_box">
             <img src="../assets/login_logo.png" />
            <p class="login_title">亚马逊半自动发信管理系统</p>
           
            <div class="login_menu">

                <el-input class="login_input"  prefix-icon="User" v-model="userName"  placeholder="请输入用户名称" />
                <el-input class="login_input"  prefix-icon="Lock" type="password" v-model="password"  placeholder="请输入登录密码" />
                <el-button class="login_btn" @click="loginEvent" type="success">登录</el-button>
            </div>
        </div>
        <div class="foot_main">
            ©2022-SENEE科技有限公司版权所有<br /><a  href="https://beian.miit.gov.cn/" target="_blank">琼ICP备20001897号-4</a>
        </div>
    </div>
</template>
<script>
import { defineComponent } from '@vue/composition-api'
import {postEventToken,cookie} from '../js/common'
import { ElMessage } from 'element-plus'
import { useRouter } from 'vue-router';
import { ref } from 'vue'
export default defineComponent({
    setup() {
        let router = useRouter()
        // aqua
        // 123456
        const userName = ref('')
        const password = ref('')
        const loginEvent= ()=>{
            let url="http://175.178.91.130/api/Login/ByPass"
            if(!userName.value){
                ElMessage({
                        message: "请输入用户",
                        type: 'warning',
                    })
            }else if(!password.value){
                    ElMessage({
                        message: "密码",
                        type: 'warning',
                    })
            }
            postEventToken(url,{
                "userName": userName.value,
                "userPass": password.value,
                "app": "string"
            },(res)=>{
                console.log(res)
                if(res.data){
                     ElMessage({
                        message: "登录成功",
                        type: 'success',
                    })
                    cookie.set("token",res.data)
                    router.push("/updataAsin")
                }else{
                     ElMessage({
                        message: res.errorMsg,
                        type: 'warning',
                    })
                }
            },(err)=>{
                console.log(err)
                 ElMessage({
                        message: err,
                        type: 'warning',
                    })
            })
        }
        return{
            userName,
            password,
            loginEvent
        }
    }
  
})
</script>
<style>
        .el-button--success{
            background: #1abc9c;
            width: 100%;
            border: 1px solid #1abc9c;
            height: 40px;
        }
        .el-button--success:hover{
             background: #1abc9c;
        }
        .login_input{
            height: 40px;
        }
</style>
<style lang="scss" scoped>
@import '../scss/LoginP.scss'
</style>
