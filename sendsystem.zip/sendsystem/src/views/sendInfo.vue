<template>
    <div class="common-layout">
    <el-container>
      <el-aside width="200px">
        <navMain></navMain>
      </el-aside>
      <el-main>
            <div class="info_main">
                <p class="info_title">亚马就会话记录页</p>
                <div class="info_all_main">
                    <div class="info_all_box">
                        <p class="info_nt">发送总数</p>
                        <p class="info_num">{{Total}}</p>
                    </div>
                     <div class="info_all_box">
                         <p class="info_nt" style="color:red">发送失败</p>
                        <p class="info_num">{{Fail}}</p>
                     </div>
                      <div class="info_all_box">
                         <p class="info_nt" style="color:#15d131">发送成功</p>
                        <p class="info_num">{{Success}}</p>
                      </div>
                </div>
                <div class="search_main">
                    <div style="padding:5px 0">
                            <span style="padding-right:10px;display:inline-block;vertical-align: middle;">发送时间:</span>
                                   <el-date-picker
                                v-model="searchDate"
                                type="daterange"
                                range-separator="To"
                                start-placeholder="开始日期"
                                end-placeholder="结束日期"
                                size="small"
                                style="width:300px;margin-right:20px;vertical-align: middle;"
                            />
                            <span  style="padding-right:10px;display:inline-block;vertical-align: middle;">状态:</span>
                                <el-select v-model="status" @change="SearchEvent" style="width:150px;margin-right:20px"  size="small">
                                <el-option label="全部" value="" />
                                <el-option label="成功" value="1" />
                                <el-option label="失败" value="0" />
                                <el-option label="提示" value="3" />
                            </el-select>
                            <span  style="padding-right:10px;display:inline-block;vertical-align: middle;">亚马逊账号:</span>
                            <el-input v-model="userCode"  style="width:150px;margin-right:20px" size="small"></el-input>
                      
                    </div>
                     <div style="padding:5px 0">
                            <span  style="padding-right:10px;display:inline-block;vertical-align: middle;">Seller ID:</span>
                            <el-input v-model="seller"  style="width:150px;margin-right:163px" size="small"></el-input>
                            <span  style="padding-right:10px;display:inline-block;vertical-align: middle;">店铺名称:</span>
                                <el-input v-model="shopName"  style="width:150px;margin-right:50px" size="small"></el-input>
                            <span  style="padding-right:10px;display:inline-block;vertical-align: middle;">ASIN:</span>
                            <el-input v-model="asin"  style="width:150px;margin-right:20px" size="small"></el-input>
                      
                    </div>
                     <div style="padding:5px 0">
                        <el-button type="primary" @click="SearchEvent" size="small">搜 索</el-button>
                        <el-button size="small" @click="resetEvent">重 置</el-button>
                        <el-button size="small" @click="ChatLog('true','纪录')">导 出</el-button>
                        <el-button type="danger" size="small" @click="delectInfo">删除选中</el-button>
                     </div>

                     <div class="table_main">
                        <p class="table_main_title">会话数据列表</p>
                        <el-table
                            ref="multipleTableRef"
                            :data="tableData"
                            style="width: 100%"
                            @selection-change="handleSelectionChange"
                        >
                            <el-table-column type="selection" width="55" />
                            <el-table-column label="发送时间">
                            <template #default="scope">{{ scope.row.SendTime }}</template>
                            </el-table-column>
                            <el-table-column property="Status" label="状态" width="120" >
                              <template #default="scope">
                                <span style="color:red" v-if="scope.row.Status == '0'">失败</span>
                                <span style="color:green"  v-if="scope.row.Status == '1'">成功</span>
                                <span  style="color:blue" v-if="scope.row.Status == '3'">提示</span>
                               </template>
                            </el-table-column>
                            <el-table-column property="ErrText" label="失败原因"  show-overflow-tooltip />
                            <el-table-column property="User" label="亚马逊账号"  />
                            <el-table-column property="SendContent" label="发送内容"  />
                            <el-table-column property="Seller" label="seller ID" width="120" />
                            <el-table-column property="ShopName" label="店铺名称"  />
                            <el-table-column property="Asin" label="ASIN" width="120" />
                        </el-table>
                     </div>
                     <div class="page_main">
                        <el-pagination
                            v-model:current-page="currentPage"
                            v-model:page-size="pageSize"
                            :disabled="disabled"
                            :page-sizes="[10,100, 200, 300, 400]"
                            layout="sizes, prev, pager, next, jumper"
                            :total="Total"
                            @size-change="handleSizeChange"
                            @current-change="handleCurrentChange"
                            />

                     </div>
                </div>
            </div>
      </el-main>
    </el-container>
  </div>
</template>
<script>
import { defineComponent } from '@vue/composition-api'
import navMain from "../components/navMain.vue"
import { ElMessage,ElMessageBox  } from 'element-plus'
import {useRouter} from 'vue-router'
import {postEventTokenAuthorization,cookie, postEventToken} from '../js/common'
   import { ref } from 'vue'
export default defineComponent({
    setup() {
        const router = useRouter()
        if(!cookie.get("token")){
          ElMessage({
              message: "登录过期，请先登录",
              type: 'warning',
          })
          router.push("/Login")  
        }
        const searchDate = ref("")
        const status = ref("")
        const userCode = ref("")
         const seller = ref("")
        const shopName = ref("")
        const asin = ref("")
        const currentPage = ref(1)
        const pageSize = ref(10)
        const disabled = ref(false)
        const Total = ref(0)
        const Success = ref(0)
        const Fail = ref(0)
        const tableData = ref([])
        const multipleSelection = ref([])
const resetEvent = ()=>{
  status.value = ""
  seller.value = ""
  userCode.value = ""
  shopName.value = ""
  asin.value = ""
  searchDate.value = ""
}
const ElMessageEvent = (type,text)=>{
      ElMessage({
         message: text,
         type: type,
      })
}
const ChatStat = ()=>{
  let url = "http://175.178.91.130/api/AMZ/ChatStat"
   let a = cookie.get("token")
     let searchDateL = ""
  let searchDateR = ""
  if(searchDate.value.length > 0){
   let searchDateLM = searchDate.value[0]
   let searchDateRM = searchDate.value[1]
   searchDateL = searchDateLM.getFullYear()+"-"+(searchDateLM.getMonth()+1 > 9 ? searchDateLM.getMonth()+1 : ("0"+(searchDateLM.getMonth()+1)))+"-"+(searchDateLM.getDate()>9?searchDateLM.getDate():("0"+searchDateLM.getDate()))
   searchDateR = searchDateRM.getFullYear()+"-"+(searchDateRM.getMonth()+1 > 9 ? searchDateRM.getMonth()+1 : ("0"+(searchDateRM.getMonth()+1)))+"-"+(searchDateRM.getDate()>9?searchDateRM.getDate():("0"+searchDateRM.getDate()))
  }
  postEventTokenAuthorization(url,{
     "page": currentPage.value,
      "pageSize": pageSize.value,
      "orderByDesc": true,
      // "orderByField": "",
      "getTotalCount": true,
      "sendTime": searchDateL ? (searchDateL+","+searchDateR):"",
      "status":status.value,
      "user": userCode.value,
      "seller": seller.value,
      "shopName": shopName.value,
      "asin": asin.value
  },a,(res)=>{
    console.log(res)
    try{
      Total.value = res.data.Total
      Success.value = res.data.Success
      Fail.value = res.data.Fail
    }catch (e){
      ElMessageEvent('warning',e)
    }
  },(err)=>{
    ElMessageEvent('warning',err)
  })
}
const SearchEvent = ()=>{
  currentPage.value = 1
  ChatLog("","")
}

const ChatLog = (exportModule,exportFileName)=>{
  console.log(searchDate.value,11111)
  let searchDateL = ""
  let searchDateR = ""
  if(searchDate.value.length > 0){
   let searchDateLM = searchDate.value[0]
   let searchDateRM = searchDate.value[1]
  searchDateL = searchDateLM.getFullYear()+"-"+(searchDateLM.getMonth()+1 > 9 ? searchDateLM.getMonth()+1 : ("0"+(searchDateLM.getMonth()+1)))+"-"+(searchDateLM.getDate()>9?searchDateLM.getDate():("0"+searchDateLM.getDate()))
   searchDateR = searchDateRM.getFullYear()+"-"+(searchDateRM.getMonth()+1 > 9 ? searchDateRM.getMonth()+1 : ("0"+(searchDateRM.getMonth()+1)))+"-"+(searchDateRM.getDate()>9?searchDateRM.getDate():("0"+searchDateRM.getDate()))
   }
  let url = "http://175.178.91.130/api/AMZ/ChatLog"
   let a = cookie.get("token")
   ChatStat()
  postEventTokenAuthorization(url,{
      "page": currentPage.value,
      "pageSize": pageSize.value,
      "orderByDesc": true,
      "orderByField": "id",
      "getTotalCount": true,
      "export":exportModule ? true :  false,
      "hasExportPermission": true,
      "exportModule": exportModule ? exportModule : "false",     //是否有导出权限 true/false
      "exportFileName": exportFileName? exportFileName:"",    //导出文件的名字
      "sendTime": searchDateL ? (searchDateL+","+searchDateR):"",
      "status": status.value,
      "user": userCode.value,
      "seller": seller.value,
      "shopName": shopName.value,
      "asin": asin.value
  },a,(res)=>{
    console.log(res)
    if(res.errorCode == 401){
      ElMessageEvent('warning',res.errorMsg)
      router.push("/Login")
    }
    if(exportModule){
      window.open(res.data)
    }else{
      if(res.data && res.data.Items){
        tableData.value = res.data.Items
      }
    }
  },(err)=>{
    ElMessageEvent('warning',err)
  })
}


const delectInfo = ()=>{
   if(multipleSelection.value.length == 0){
         ElMessageEvent('warning',"请选择要删除的数据")
         return false
      }
   ElMessageBox.confirm(
    '是否要删除一下内容?',
    '提示',
    {
      confirmButtonText: '是',
      cancelButtonText: '否',
      type: 'warning',
    }
  )
    .then(() => {
      let url = "http://175.178.91.130/api/AMZ/DelChat"
      let ids = []
     
      for(let i = 0; i < multipleSelection.value.length;i++){
        ids.push(multipleSelection.value[i].Id)
        if(i == multipleSelection.value.length -1){
          postEventToken(url,{
            "ids": ids
          },(res)=>{
            console.log(res)
              ElMessage({
                type: 'success',
                message: res.data,
              })
              ChatLog("","")
          },(err)=>{
            console.log(err)
          })
        }
      }
      
    })
    .catch(() => {

    })
  
}

const handleSizeChange = (val) => {
  console.log(`${val} items per page`)
  ChatLog("","")
}
const handleCurrentChange = (val) => {
  console.log(`current page: ${val}`)
  ChatLog("","")
}

const handleSelectionChange = (val) => {
  multipleSelection.value = val
  console.log(multipleSelection.value)
}
ChatLog("","")
        return {
            searchDate,
            status,
            userCode,
            seller,
            shopName,
            asin,
            tableData,
            handleSelectionChange,
            currentPage,
            pageSize,
            disabled,
            handleSizeChange,
            handleCurrentChange,
            ChatLog,
            delectInfo,
            Total,
            Success,
            Fail,
            resetEvent,
            SearchEvent

        }
    },
     components:{
        navMain
    }
})
</script>
<style lang="scss">
    .common-layout{
        min-width: 1500px;
         .el-main{
            padding: 0 0 0 0;
         }
        .info_main{
            background: #f0f2f5;
            width: 100%;
        }
        .info_title{
            background: #fff;
            font-size: 16px;
            padding: 10px 10px 10px 20px;
            margin: 0;
            font-weight: bold;
            margin-bottom: 10px;
        }
        .info_all_main{
            width: 96%;
            margin: 10px auto;
            background: #ffffff;
            padding: 15px 0;
            display: flex;
            .info_all_box{
                text-align: center;
                flex: 1;
                height: 50px;
                
                &:nth-child(2){
                    border-left: 1px solid #efefef;
                    border-right: 1px solid #efefef;
                }
                p{
                    font-size: 13px;
                    // font-weight: bold;
                    margin:0;
                    
                    &.info_nt{
                        color: #666;
                        font-weight: bold;
                        margin: 2px 0 5px 0 ;
                    }
                    &.info_num{
                        // font-weight: 400;
                        font-size: 22px;
                        color: #333;
                    }
                }
            }
            
        }
        .search_main{
                width: 96%;
                margin: 30px auto;
                font-size: 12px;
                font-weight: bold;
            }
            .table_main_title{
                background: #999;
                color: #333;
                padding: 3px 2px;
                margin: 0;
            }
            .table_main{
               padding-top: 30px;
               .el-table__body{
                font-size: 13px;
               } 
            }
            .page_main{
                padding: 60px 0;
                text-align: center;
                position: relative;
                .el-pagination{
                    position: absolute;
                    left: 50%;
                    transform: translateX(-50%);
                    top:40px
                }
                .number,.btn-prev,.btn-quicknext,.btn-next{
                    background: transparent;
                }
            }
    }
</style>
