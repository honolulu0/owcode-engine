import { createRouter, createWebHashHistory } from 'vue-router';
// import store from '../store/index'
const Login = () =>
  import(/* webpackChunkName: "index" */ '../views/LoginP.vue');
const updataAsin = () =>
  import(/* webpackChunkName: "index" */ '../views/updataAsin.vue');
const sendInfo =()=>
    import(/* webpackChunkName: "index" */ '../views/sendInfo.vue');
const hash = createWebHashHistory();
const router = createRouter({
  history: hash,
  routes: [
    {
      path: '/',
      name: 'Login',
      component: Login,
      meta: {
        keepAlive: false // 是否缓存组件
      }
    },
    {
      path: '/Login',
      name: 'Login',
      component: Login,
      meta: {
        keepAlive: false // 是否缓存组件
      }
    },
    {
        path: '/updataAsin',
        name: 'updataAsin',
        component: updataAsin,
        meta: {
          keepAlive: false // 是否缓存组件
        }
      },
      {
        path: '/sendInfo',
        name: 'sendInfo',
        component: sendInfo,
        meta: {
          keepAlive: false // 是否缓存组件
        }
      },
  ]
});

export default router;
