<template>
    <div class="nav_menu">
        <h3 class="nav_title">亚马逊自动发信</h3>
          <el-menu
        :default-active=selectType
        class="nav_menu_main"
      >
        <el-menu-item index="1">
         <el-icon><UploadFilled /></el-icon>
         <router-link style="width:100%" to="/updataAsin">ASIN码上传页</router-link>

        </el-menu-item>
        <el-menu-item index="2">
          <el-icon><Menu /></el-icon>
            <router-link style="width:100%" to="/sendInfo">亚马逊会话记录页</router-link>
        </el-menu-item>
      </el-menu>
    </div>
</template>
<script>
import { defineComponent } from '@vue/composition-api'
import {useRoute} from 'vue-router'

export default defineComponent({
    setup() {
        const route = useRoute()
        const name = route.name
        let selectType = "0"
        if(name == "updataAsin"){
            selectType = "1"
        }else if(name == "sendInfo"){
            selectType = "2"
        }
        return{
            selectType
        }
    },
})
</script>
<style  lang="scss">
    .nav_menu{
        width: 210px;
        position: fixed;
        left: 0;
        top: 0;
        height: 100%;
        z-index: 10;
        background: #001529;
        .nav_title{
            padding: 10px 0  10px 10px;
            margin: 0;
            color: #fff;
            background: #00284d;
        }
        .nav_menu_main{
            padding-top:25px ;
        }
        .el-menu{
            background: transparent;
            li{
                 color: #fff;
                 &:hover{
                    background: #0b1e31;
                 }
                 &.is-active{
                     background: #0b1e31;
                 }
            }
           
        }
        a{
            text-decoration: none;
            color: #fff;
        }
    }
</style>
