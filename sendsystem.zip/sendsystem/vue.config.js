const { defineConfig } = require('@vue/cli-service')
module.exports = defineConfig({
  transpileDependencies: true,
  devServer:{
    host:"w-test.sui10.com",
    port:8080,
  },
  publicPath:"/sendbot"
 
})
